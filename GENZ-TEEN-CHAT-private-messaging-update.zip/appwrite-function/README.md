GENZ TEEN CHAT private messaging function

Deploy this function only after confirming the required tables and API key scopes. Keep APPWRITE_API_KEY in Function Variables as a Secret; never place it in browser files.

Required variables: APPWRITE_DATABASE_ID=genz-chat-db, PRIVATE_MESSAGES_TABLE_ID=private_messages, BLOCKS_TABLE_ID=blocks, REPORTS_TABLE_ID=reports, and APPWRITE_API_KEY (Secret). Appwrite provides APPWRITE_FUNCTION_API_ENDPOINT and APPWRITE_FUNCTION_PROJECT_ID.

Required columns: private_messages: conversationId, senderId, receiverId, messageText, sentAt. blocks: blockerId, blockedId, createdAt. reports: reporterId, reportedUserId, reason, createdAt, and optional messageId.

The browser calls the function domain https://starter-function-pw9b.nyc.appwrite.run and sends a short-lived Appwrite user JWT. Test using two separate accounts. Verify CORS, JWT validation, row permissions, and function logs before using the site with other people.
